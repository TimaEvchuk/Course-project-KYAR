import { burgerMenuFunc } from "./burger-menu.js";
import { formClipFunc } from "./form-clip.js";
import { yandexMapFunc } from "./yandex-map.js";
document.addEventListener('DOMContentLoaded', function() {
  yandexMapFunc();
})
burgerMenuFunc();
formClipFunc();